package com.capgemini.bank.bean;

public class DemandDraft {
	// Declaring Variables for Banking Applications
		String pnumber,name,remarks,infavor;
	  Integer Com,tid, demanddraft;
	 
		// Generate getters and Setters for all the Declared variable
		public Integer getTid() {
			return tid;
		}

		public void setTid(Integer tid) {
			this.tid = tid;
		}

		public Integer getCom() {
			return Com;
		}

		public void setCom(Integer com) {
			Com = com;
		}

		public String getPnumber() {
			return pnumber;
		}
		
		public void setPnumber(String pnumber) {
			this.pnumber = pnumber;
		}
		
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public String getRemarks() {
			return remarks;
		}
		
		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}
		
		public String getInfavor() {
			return infavor;
		}
		public void setInfavor(String infavor) {
			this.infavor = infavor;
		}
		public Integer getDemanddraft() {
			return demanddraft;
		}
		public void setDemanddraft(Integer demanddraft) {
			this.demanddraft = demanddraft;
		}
	}

