package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;


import java.util.logging.Logger;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDao {

	static Logger Log=Logger.getLogger(DemandDraft.class.getName());
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) 
	{
		
		Date d=new Date();
		 // step 1: loading driver class and registering it
          try
		   {
			   Class.forName("oracle.jdbc.driver.OracleDriver");
		   }
		  catch(ClassNotFoundException e)
		   {
			   e.printStackTrace();
		   }
	      try
	       {
	    	// step 2: Establish a connection
			   String url="jdbc:oracle:thin:@localhost:1521:XE";
			   String user="hr";
			   String pass="hr";
			   Connection con=DriverManager.getConnection(url, user, pass);
			  // Log.info("conenction started");
			   // Application of Log Info to print on Screen
			  // System.out.println("Connection opened");
			   
			   //step 3: Create prepared statement
			   String sql1="insert into demand_draft values(?,?,?,?,?,?,?,?)";
			   
			   PreparedStatement ps= con.prepareStatement(sql1);
			   Statement st=con.createStatement();//import using java.sql
			   // Using Sequence to generate Transcation_Id
			   //Step 4: 
			   ResultSet rs=st.executeQuery("select Transaction_id_Seq.nextval from dual");
			   while(rs.next())
			   {
				   demandDraft.setTid(Integer.valueOf(rs.getInt(1)));
			   }
			 //  Log.info("setting value in table");
			   ps.setInt(1, demandDraft.getTid());
			   ps.setString(2, demandDraft.getName());
			   ps.setString(3, demandDraft.getInfavor());
			   ps.setString(4, demandDraft.getPnumber());
			   ps.setDate(5, new java.sql.Date(d.getTime()));
			   ps.setInt(6, demandDraft.getDemanddraft());
			   ps.setInt(7, demandDraft.getCom());
			   ps.setString(8, demandDraft.getRemarks());
			   ps.executeUpdate();
			 //  Log.info("query executed");
			   System.out.println("1 row updated.");
			   con.close();
			  // Log.info("conenction closed");
	       }
	       catch(SQLException e)
	       {
	    	   e.printStackTrace();
	       }
		
		return 0;
}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}
}