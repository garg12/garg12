package com.capgemini.bank.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.logging.Logger;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;

public class Client {
	
	static Logger Log=Logger.getLogger(Client.class.getName());
	public static void main(String[] args) throws SQLException, IOException
	{
		
   // Declaration through logger
	//Log.info("Test logger");
	Integer ch;
	// Buffer Reader declaration
	BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
	//Displaying Menu for the user
	System.out.println("***** Welcome in XYZ Bank*****");
	System.out.println("Enter your choice");
	System.out.println("1) Enter Demand Draft Details");
	System.out.println("2) Exit");
	ch=Integer.parseInt(br.readLine());
	
	// Taking Input from user as per the requirement as per their choices
	switch(ch)
	{
	case 1:DemandDraft dd1=new DemandDraft();
	       System.out.println("Enter the name of the customer: ");
	       dd1.setName(br.readLine());
	       System.out.println("Enter customer phone number: ");
	       dd1.setPnumber(br.readLine());
	       System.out.println("In Favour of: ");
	       dd1.setInfavor(br.readLine());
	       System.out.println("Enter Demand Draft amount (in Rs): ");
	       dd1.setDemanddraft(Integer.parseInt(br.readLine()));
	       System.out.println("Enter Remarks: ");
	       dd1.setRemarks(br.readLine());
	       DemandDraftService dds=new DemandDraftService();
	       dds.addDemandDraftDetails(dd1);
	       System.out.println("Congratulations!!");
	       System.out.println("Your Demand Draft request has been successfully registered along with the "+dd1.getTid());
	       
		    break;
	case 2:System.exit(0);
		break;
	default:System.err.println("Invalid Choice");
	
	}
}

}
