package com.capgemini.bank.service;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService.CharacterInvalidException;
import com.capgemini.bank.service.DemandDraftService.DemandDraftInvalidException;
import com.capgemini.bank.service.DemandDraftService.NumbersInvalidException;
import com.capgemini.bank.service.IDemandDraftService;

public class DemandDraftService implements IDemandDraftService {

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft)
	{
		//Validations for name;
		
		
		try
		{
			if(!(demandDraft.getName().toString().matches("[a-z A-Z]+")))
			throw new CharacterInvalidException();
		}
		catch( CharacterInvalidException c)
		{
			c.Message();
		}
		
		try
		{
			if(!(demandDraft.getPnumber().toString().matches("[0-9]{10}")))
			throw new NumbersInvalidException();
		}
		catch( NumbersInvalidException d)
		{
			d.Message1();
		}
		
		try
		{
			if(!(demandDraft.getDemanddraft().toString().matches("[0-9]+")) || demandDraft.getDemanddraft()>500000)
			throw new DemandDraftInvalidException();
		}
		catch( DemandDraftInvalidException f)
		{
			f.Message2();
		}
		
		
		String c=demandDraft.getName();
		for(int j=0;j<c.length();j++)
		{
		    char n=c.charAt(j);
			if(((int)n<65 || (int)n>122) && (int)n!=32)
			{
			System.err.println("Only Characters are allowed");
			System.exit(0);
			}
		}
		
		if(demandDraft.getDemanddraft()<0)
		{
			System.err.println("Demand Draft Amount should be a positive amount.");
			System.exit(0);
		}
		
		if(demandDraft.getDemanddraft()>500000)
		{
			System.err.println("No Commission avavilable for this amount.");
			System.exit(0);
		}
		
		//Commission Calculations
		if(demandDraft.getDemanddraft()<=5000)
			demandDraft.setCom(10);
		else if(demandDraft.getDemanddraft()<=10000)
			demandDraft.setCom(41);
		else if(demandDraft.getDemanddraft()<=100000)
			demandDraft.setCom(51);
		else
			demandDraft.setCom(306);
	
		DemandDraftDAO ddd=new DemandDraftDAO();
		ddd.addDemandDraftDetails(demandDraft);
		return 0;
	}
	
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId)
	{
		return null;
	}
	class CharacterInvalidException extends Exception
	{
		void Message()
		{
			System.err.println("Only Characters are allowed in name");
			System.exit(0);
		}
	}
	class NumbersInvalidException extends Exception
	{
		void Message1()
		{
			System.err.println("Only (0-9) digits are allowed in Mobile Number");
			System.exit(0);
		}
	}
	class DemandDraftInvalidException extends Exception
	 {
		void Message2()
		{
			System.err.println("Demand Draft amount neither should be leass than 0 nor more than 500000 ");
			System.exit(0);
		}
	}
}
