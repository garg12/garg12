package com.capgemini.bank.service;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;

public class Junit {
	@Test
	public void testAddDemandDraftDetails(){
		DemandDraft demandDraft = new DemandDraft();
		demandDraft.setName("Test");
		demandDraft.setPnumber("9876543210");
		demandDraft.setInfavor("ABC comp");
		demandDraft.setDemanddraft(50000);
		demandDraft.setRemarks("Good job");
		demandDraft.setCom(300);
		DemandDraftDAO test = new DemandDraftDAO();
		assertEquals(0, test.addDemandDraftDetails(demandDraft));
	}

}
