package com.cucumber.CucumberTest.CucumberTest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions
 (
 features = {"classpath:features/login.feature"}
 , plugin = {"pretty", "html:target/report"}
 , glue= {"com.cucumber.CucumberTest.login"}
)

public class Login {

}
