package com.capgemini.domain.impl;

import com.capgemini.domain.Messaging;

public class ActiveMQMessaging implements Messaging {

	public void sendMessage()
	{
		System.out.println("Hey Person messaging");
	}

	

}
