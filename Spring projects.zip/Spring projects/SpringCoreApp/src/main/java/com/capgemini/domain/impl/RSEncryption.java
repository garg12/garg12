package com.capgemini.domain.impl;

import com.capgemini.domain.Encryption;

public class RSEncryption implements Encryption {
	public void encryptData()
	{
		System.out.println("Hey Person encryption");
	}
}
