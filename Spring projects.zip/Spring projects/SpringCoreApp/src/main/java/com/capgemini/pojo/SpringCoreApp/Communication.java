package com.capgemini.pojo.SpringCoreApp;

import com.capgemini.domain.Encryption;
import com.capgemini.domain.Messaging;

public class Communication {
 
	private Messaging messaging;
	private Encryption encryption;
	 
	public Communication(Encryption encryption)
	{
		this.encryption=encryption;
	}
	public void setMessaging(Messaging messaging)
	{
		this.messaging= messaging;
	}
	public void communicate()
	{
		encryption.encryptData();
		messaging.sendMessage();
	}
	
}
