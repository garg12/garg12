package com.capgemini.pojo.database.SpringdatabaseApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class OracleDatabase {
  private String Schema;
  private String dbname;
  private String hostname;
  private String password;
  private Integer portno ;
  private String uname ;
  
  
public String getSchema() {
	return Schema;
}
public void setSchema(String schema) {
	Schema = schema;
}
public String getDbname() {
	return dbname;
}
public void setDbname(String dbname) {
	this.dbname = dbname;
}
public String gethostname() {
	return hostname;
}
public void sethostname(String hostname) {
	this.hostname = hostname;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Integer getPortno() {
	return portno;
}
public void setPortno(Integer portno) {
	this.portno = portno;
}
public void setUname(String uname) {
	this.uname = uname;
}
  
public void checkConnection()
{
	try
	   {
	   Class.forName("oracle.jdbc.driver.OracleDriver");
	   }
	   catch(ClassNotFoundException e)
	   {
	   e.printStackTrace();
	   }
	       try
	       {
	   String url="jdbc:"+getDbname()+":thin:"+gethostname()+":"+getPortno()+":"+getSchema();
	  
	   Connection conn=DriverManager.getConnection(url, uname, password);
	  
	        if(conn.isClosed() || conn!=null)
	        {
	            System.out.println("Connected !! \n Connection is Opened");
	        }
	       }
	   
	catch(SQLException e)
       {
       e.printStackTrace();
       }
	       
	      
	   }
}
