package com.capgemini.check;

public class checkConnectionimpl {

}
