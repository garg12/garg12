package com.capgemini.check;

public interface checkConnection {
	public void checkConnection();
}
