import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.pojo.SpringApp2.Sample2;


public class AppMain1 {

	public static void main(String args[])
	{
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("app-config.xml");
		Sample2 app=(Sample2)context.getBean("capgemini");
		app.display();
	}
}
