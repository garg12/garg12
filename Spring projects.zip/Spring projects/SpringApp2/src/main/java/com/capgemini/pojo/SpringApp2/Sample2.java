package com.capgemini.pojo.SpringApp2;

public class Sample2 {

		String company;
		Integer empid;
		Integer salary;
		
		
		
		public void setSalary(int salary)
		{
			this.salary = salary;
		}
		
		Sample2(int emp,String name)
		{
			empid=emp;
			company=name;
		}
		
		
		public void display()
		{
			System.out.println("Emp-id"+empid+"Company"+company+"Salary"+salary) ;
			
		}
	}

