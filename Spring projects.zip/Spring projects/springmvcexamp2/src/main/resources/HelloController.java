package org.capgemini;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class HelloController {
	
	@RequestMapping("/login")
	public ModelAndView saylogin(@RequestParam("user")String name, @RequestParam("pass")String password)
	{
		String message=("Hey "+name+" Congrats!! You have Entered Successfully");
		return new ModelAndView("login", "msg", message);

		}
}