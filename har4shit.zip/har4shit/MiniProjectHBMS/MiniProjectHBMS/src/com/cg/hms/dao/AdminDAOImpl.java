package com.cg.hms.dao;



import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.hms.bean.BookingDetails;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomDetails;
import com.cg.hms.bean.Users;
import com.cg.hms.exception.HotelException;
import com.cg.hms.util.DBUtil;

public class AdminDAOImpl implements IAdminDAO{

	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rst=null;
	ArrayList<Hotels> hotelid=null;
	ArrayList<Users> hotel_id=null;
	ArrayList<BookingDetails> bkdate=null;
	ArrayList<RoomDetails> rmdtls=null;
	RoomDetails rmdtl=null;
	@Override
	public String isRoleAdmin(int adminusername, String adminpassword)
			throws HotelException {
		String role=null;
		try {

			con=DBUtil.getCon();
			st=con.createStatement();	
			rst=st.executeQuery(AdminQueryMapper.adminLoginQuery);
			System.out.println(adminusername);
			while(rst.next())
			{
				if(adminusername==rst.getInt("user_id"))
				{		
					if (adminpassword.equals(rst.getString("password")))
					{
						role=rst.getString("role");
						System.out.println(role);	
					}
				}
				/*else
				{}*/
			}
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		return role;
	}

	@Override
	public int generateHotelId() throws HotelException {
		int generatedHotelId=0;
		try {
			con=DBUtil.getCon();
			st=con.createStatement();
			rst=st.executeQuery(AdminQueryMapper.hotelIDSequenceQuery);
			rst.next();
			generatedHotelId=rst.getInt(1);
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		return generatedHotelId;
	}

	@Override
	public int generateRoomId() throws HotelException {
		int generatedRoomId=0;
		try {
			con=DBUtil.getCon();
			st=con.createStatement();
			rst=st.executeQuery(AdminQueryMapper.roomIDSequenceQuery);
			rst.next();
			generatedRoomId=rst.getInt(1);
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		return generatedRoomId;
	}

	@Override
	public int addHotelDetails(Hotels hotel) throws HotelException {
		int hotelId=generateHotelId();
		int rowinserted=0;
		try {
			System.out.println("in dao");
			System.out.println("******" +hotelId);
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminAddHotelQuery);
			System.out.println("in dao");
			pst.setInt(1, hotelId);
			pst.setString(2,hotel.getCity());
			pst.setString(3, hotel.getHotel_name());
			pst.setString(4, hotel.getAddress());
			pst.setString(5, hotel.getDescription());
			pst.setFloat(6, hotel.getAvg_rate_per_night());
			pst.setLong(7, hotel.getPhone_no1());
			pst.setLong(8, hotel.getPhone_no2());
			pst.setString(9, hotel.getRating());
			pst.setString(10, hotel.getEmail());
			pst.setLong(11, hotel.getFax());
			System.out.println("in dao********");
			rowinserted=pst.executeUpdate();
			System.out.println("in dao");
			if(rowinserted==0)
			{
				hotelId=0;
			}
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		return hotelId;
	}

	@Override
	public int deleteHotelDetails(int hotelId) throws HotelException {
		int deletedrow=0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminDeleteHotelQuery);
			pst.setInt(1, hotelId);
			deletedrow=pst.executeUpdate();
			if(deletedrow==0)
			{
				deletedrow=0;
			}
		} 
		catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		return deletedrow;
	}

	@Override
	public int addRoomDetails(RoomDetails rmdtls) throws HotelException {
		int roomId=generateRoomId();
		//int hotelId=generateHotelId();
		int rowinserted=0;
		try {

			con=DBUtil.getCon();
			System.out.println(roomId);
			pst=con.prepareStatement(AdminQueryMapper.adminAddRoomInfoQuery);
			pst.setInt(1, roomId);
			pst.setInt(2,rmdtls.getHotel_id());
			pst.setString(3, rmdtls.getRoom_no());
			pst.setString(4, rmdtls.getRomm_type());
			pst.setFloat(5, rmdtls.getPer_night_rate());
			pst.setString(6, rmdtls.getAvailability());

			System.out.println(rmdtls.getRoom_no()+""+rmdtls.getRomm_type()+""+rmdtls.getPer_night_rate()+""+rmdtls.getAvailability()+""+rmdtls.getHotel_id());
			System.out.println("after query");
			rowinserted=pst.executeUpdate();
			System.out.println("in dao");
			if(rowinserted==0)
			{
				roomId=0;
			}
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		return roomId;
	}

	@Override
	public int deleteRoomDetails(int roomId) throws HotelException {
		int deletedrow=0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminDeleteRoomInfoQuery);
			pst.setInt(1, roomId);
			deletedrow=pst.executeUpdate();
			if(deletedrow==1)
			{
				return deletedrow;
			}
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}

		return deletedrow;
	}

	@Override
	public ArrayList<Hotels> selectHotelId() throws HotelException {
		hotelid=new ArrayList<Hotels>();
		Hotels hotel=null;
		try {
			con=DBUtil.getCon();
			st=con.createStatement();
			rst=st.executeQuery(AdminQueryMapper.adminSelectHotelIdQuery);
			while(rst.next())
			{
				hotel=new Hotels(rst.getInt("hotel_id"));
				hotelid.add(hotel);
			}
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		return hotelid;
	}

	@Override
	public ArrayList<Hotels> fetchAllHotels() throws HotelException {
		hotelid=new ArrayList<Hotels>();
		Hotels hotel=null;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminViewAllHotelsQuery);
			rst=pst.executeQuery();
			System.out.println("in dao");
			while(rst.next())
			{
				hotel=new Hotels(rst.getInt("hotel_id"),rst.getString("city"),
						rst.getString("hotel_name"),rst.getString("address"),
						rst.getString("description"),rst.getFloat("avg_rate_per_night"),
						rst.getLong("phone_no1"),rst.getLong("phone_no2"),
						rst.getString("rating"),rst.getString("email"),
						rst.getLong("fax"));
				hotelid.add(hotel);
			}
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		System.out.println("in dao ****");
		return hotelid;
	}

	@Override
	public ArrayList<BookingDetails> fetchBookingsbyHotelId(int hotelId)
			throws HotelException {
		bkdate=new ArrayList<BookingDetails>();
		BookingDetails bkdtls=null;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminViewBookingsQuery);
			pst.setInt(1, hotelId);
			rst=pst.executeQuery();
			while(rst.next())
			{
				bkdtls=new BookingDetails(rst.getInt("booking_id"),rst.getInt("room_id"),
						rst.getInt("user_id"),rst.getDate("booked_from date"),
						rst.getString("booked_to_date"),rst.getInt("no_of_adults"),
						rst.getInt("no_of_children"),rst.getFloat("amount"));
				bkdate.add(bkdtls);
			}
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}

		return bkdate;
	}

	@Override
	public ArrayList<Users> fetchGuestNamesbyHotelId(int hotelId)
			throws HotelException {
		hotel_id=new ArrayList<Users>();
		Users user=null;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminViewGuestlistQuery);
			pst.setInt(1, hotelId);
			rst=pst.executeQuery();
			while(rst.next())
			{
				user=new Users(rst.getString("username"));
				hotel_id.add(user);
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return hotel_id;
	}

	@Override
	public ArrayList<BookingDetails> fetchBookingsByDate(Date bookingdate)
			throws HotelException {
		bkdate=new ArrayList<BookingDetails>();
		BookingDetails bookdtls=null;

		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminViewBookingDateQuery);
			pst.setDate(1, bookingdate);
			rst=pst.executeQuery();
			while(rst.next())
			{
				bookdtls=new BookingDetails();
				bkdate.add(bookdtls);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return bkdate;
	}

	@Override
	public boolean updateCity(String city,int hotelId) throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHCITYQRY);
			pst.setString(1, city);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		return false;
	}
	@Override
	public boolean updateHotelName(String hotelName, int hotelId)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHHOTELNAMEQRY);
			pst.setString(1, hotelName);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}
	@Override
	public boolean updateHAddress(String address, int hotelId)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHADDRESSQRY);
			pst.setString(1, address);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}
	@Override
	public boolean updateHDescription(String description, int hotelId)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHDESCQRY);
			pst.setString(1, description);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}
	@Override
	public boolean updateHRate(float rate, int hotelId) throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHRATEQRY);
			pst.setFloat(1, rate);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}
	@Override
	public boolean updateHPhone1(long phone1, int hotelId)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHPHONE1QRY);
			pst.setLong(1, phone1);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}
	@Override
	public boolean updateHPhone2(long phone2, int hotelId)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHPHONE2QRY);
			pst.setLong(1, phone2);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}
	@Override
	public boolean updateHRating(String rating, int hotelId)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHRATINGQRY);
			pst.setString(1, rating);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}
	@Override
	public boolean updateHEmail(String email, int hotelId)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHEMAILQRY);
			pst.setString(1, email);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}
	@Override
	public boolean updateFax(long fax, int hotelId) throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEHFAXQRY);
			pst.setLong(1, fax);
			pst.setInt(2,hotelId);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}

	@Override
	public boolean updateRoomNo(String roomno, int roomid)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEROOMNOQRY);
			pst.setString(1, roomno);
		
			pst.setInt(2,roomid);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public boolean updateRoomType(String roomtype, int roomid)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEROOMTYPEQRY);
			pst.setString(1, roomtype);
	
			pst.setInt(2,roomid);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public boolean updateNightRate(float pnr, int roomid)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEROOMNIGHTRATEQRY);
			pst.setFloat(1, pnr);			
			pst.setInt(2,roomid);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public boolean updateAvailability(String avail, int roomid)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.UPDATEROOMAVAILQRY);
			pst.setString(1, avail);
			
			pst.setInt(2,roomid);
			if(pst.executeUpdate()==1)
			{
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public ArrayList<Hotels> fetchAllHotelById(int hotelidall) throws HotelException {
		hotelid=new ArrayList<Hotels>();
		Hotels hotel=null;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminViewAllHotelIdQuery);
			pst.setInt(1, hotelidall);
			rst=pst.executeQuery();
			System.out.println("in dao");
			while(rst.next())
			{
				hotel=new Hotels(rst.getInt("hotel_id"),rst.getString("city"),
						rst.getString("hotel_name"),rst.getString("address"),
						rst.getString("description"),rst.getFloat("avg_rate_per_night"),
						rst.getLong("phone_no1"),rst.getLong("phone_no2"),
						rst.getString("rating"),rst.getString("email"),
						rst.getLong("fax"));
				hotelid.add(hotel);
			}
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		System.out.println("in dao ****");
		return hotelid;
	}

	@Override
	public ArrayList<RoomDetails> selectRoomId(int hotelId)
			throws HotelException {
		rmdtls=new ArrayList<RoomDetails>();
		RoomDetails rmd=null;
		
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminSelectRoomIdQuery);
			pst.setInt(1, hotelId);
			rst=pst.executeQuery();
			while(rst.next())
			{
				rmd=new RoomDetails(rst.getInt("room_id"));
				rmdtls.add(rmd);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return rmdtls;
	}
	@Override
	public RoomDetails checkAvailability(Date booked_from_date,String booked_to_date,String room_type)
			throws HotelException {
		
		
		//BookingDetails bkdtls=new BookingDetails();
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminupdateAvailQuery);
			pst.setDate(1, booked_from_date);
			pst.setString(2, booked_to_date);
			pst.setString(3, room_type);
			rst=pst.executeQuery();
			while(rst.next())
			{
				rmdtl=new RoomDetails(rst.getFloat("per_night_rate"),rst.getString("availability"));
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return rmdtl;
	}

	@Override
	public void updateAvailability1(int roomid)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminUpdCustAvailQuery);
			pst.setInt(1, roomid);
			pst.executeUpdate();
		} catch (Exception e) {
	
			e.printStackTrace();
		}
	}

	@Override
	public void updateNewAvailability(Date booked_to_date)
			throws HotelException {
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminUpdNewCustAvailQuery);
			pst.setDate(1, booked_to_date);
			pst.executeUpdate();
		} catch (Exception e) {
	
			e.printStackTrace();
		}
	}

	@Override
	public RoomDetails checkRoomAvail(String room_type,int hotelid) throws HotelException {
		int count=0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminCheckAvailroomQuery);
			pst.setString(1, room_type);
			pst.setInt(2, hotelid);
			rst=pst.executeQuery();
			while(rst.next())
			{
				
				rmdtl=new RoomDetails(rst.getFloat("per_night_rate"),rst.getString("availability"));
				if(rst.getString("availability").equalsIgnoreCase("yes"))
				{
					count++;
				}
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return rmdtl;
	}

	@Override
	public int showAvailCount(String room_type, int hotelid)
			throws HotelException {
		int count=0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(AdminQueryMapper.adminCheckAvailroomQuery);
			pst.setString(1, room_type);
			pst.setInt(2, hotelid);
			rst=pst.executeQuery();
			while(rst.next())
			{
				
				if(rst.getString("availability").equalsIgnoreCase("yes"))
				{
					count++;
				}
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return count;
	}	
}