package com.cg.hms.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.hms.bean.BookingDetails;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomDetails;
import com.cg.hms.bean.Users;
import com.cg.hms.exception.HotelException;
import com.cg.hms.service.AdminServiceImpl;
import com.cg.hms.service.CustomerServiceImpl;
import com.cg.hms.service.IAdminService;
import com.cg.hms.service.ICustomerService;

@WebServlet("*.do")
public class AdminController extends HttpServlet {

	String path = null;
	IAdminService hms = null;
	String target = null;
	String msg = null;
	Hotels hotel = null;
	RoomDetails room = null;
	ICustomerService cserv = null;
	ArrayList<Hotels> searchHotelList = new ArrayList<Hotels>();

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		path = request.getServletPath();
		HttpSession ses = request.getSession(true);
		switch (path) {
		case "/addLogin.do":

			// create a ref for service
			cserv = new CustomerServiceImpl();
			hms = new AdminServiceImpl();
			int username = Integer.parseInt(request.getParameter("userid"));
			ses.setAttribute("userid", username);
			String password = request.getParameter("Password");
			try {
				// System.out.println("****"
				// +hms.isRoleAdmin(username,password));
				System.out.println("In controller");
				String val = hms.isRoleAdmin(username, password);

				ses.setAttribute("value", val);
				// System.out.println(val);
				if ("admin".equalsIgnoreCase(val)) {

					target = "adminoperations.jsp";
				} else if ("customer".equalsIgnoreCase(val)) {
					ArrayList<String> cityList = cserv.showdistinctcity();
					request.setAttribute("cityList", cityList);
					
					target = "searchcity.jsp";
				} else {
					request.setAttribute("eMsg", "UserID or password incorrect");
					target = "login.jsp";
				}
			} catch (HotelException e) {
				request.setAttribute("eMsg", e.getMessage());
				target = "hotelerror.jsp";
			}
			break;

		case "/addhotel.do":

			String hotelName = request.getParameter("hotelname");
			String city = request.getParameter("city");
			String address = request.getParameter("address");
			String description = request.getParameter("description");
			float avg_rate = Float.parseFloat(request
					.getParameter("avgpernight"));
			long phoneno1 = Long.parseLong(request.getParameter("phone1"));
			;
			long phoneno2 = Long.parseLong(request.getParameter("phone2"));
			String rating = request.getParameter("rating");
			String email = request.getParameter("email");
			long faxno = Long.parseLong(request.getParameter("fax"));
			hotel = new Hotels(city, hotelName, address, description, avg_rate,
					phoneno1, phoneno2, rating, email, faxno);
			hms = new AdminServiceImpl();
			System.out.println("In controller");
			try {
				int hotelId = hms.addHotelDetails(hotel);
				System.out.println(hotelId);
				Hotels hoteljsp = new Hotels(hotelId, city, hotelName, address,
						description, avg_rate, phoneno1, phoneno2, rating,
						email, faxno);
				System.out.println("In controller");
				ses.setAttribute("val1", ses.getAttribute("value"));
				request.setAttribute("eMsg", "insertedhotel");
				request.setAttribute("hoteljsp", hoteljsp);
				target = "successadminop.jsp";
			} catch (HotelException e) {
				request.setAttribute("eMsg", e.getMessage());
				target = "hotelerror.jsp";
			}

			break;

		case "/deletehotel.do":
			int deleteIdNum = Integer.parseInt(request.getParameter("hotelid"));
			hms = new AdminServiceImpl();
			int deleteValue;
			try {
				deleteValue = hms.deleteHotelDetails(deleteIdNum);
				if (deleteValue == 1) {
					ses.setAttribute("val1", ses.getAttribute("value"));
					request.setAttribute("deleteIdNum", deleteIdNum);
					request.setAttribute("deletehotelMsg", "insertedhotel");
					target = "successadminop.jsp";
				} else {
					request.setAttribute("Msg", "Wrong Hotel ID given");
					target = "deletehotel.jsp";
				}
			} catch (HotelException e) {
				request.setAttribute("eMsg", e.getMessage());
				target = "hotelerror.jsp";
			}

			break;

		case "/addRoom.do":

			int roomhotelId = Integer.parseInt(request.getParameter("hotelid"));
			String roomno = request.getParameter("roomnum");
			String roomtype = request.getParameter("roomtype");
			float pernightrate = Float.parseFloat(request
					.getParameter("avgpernight"));
			String roomavailability = request.getParameter("avail");
			System.out.println(roomavailability);
			room = new RoomDetails(roomhotelId, roomno, roomtype, pernightrate,
					roomavailability);
			hms = new AdminServiceImpl();
			int roomId;
			try {
				roomId = hms.addRoomDetails(room);
				System.out.println(roomId);
				RoomDetails roomjsp = new RoomDetails(roomId, roomhotelId,
						roomno, roomtype, pernightrate, roomavailability);
				System.out.println(roomId);
				ses.setAttribute("val1", ses.getAttribute("value"));
				request.setAttribute("addroomMsg", "insertedhotel");
				request.setAttribute("roomjsp", roomjsp);
				target = "successadminop.jsp";
			} catch (HotelException e) {
				request.setAttribute("eMsg", e.getMessage());
				target = "hotelerror.jsp";
			}

			break;
		case "/listHotel.do":
			hms = new AdminServiceImpl();
			try {
				ArrayList<Hotels> hotelList = hms.selectHotelId();
				request.setAttribute("hotelList", hotelList);
				target = "insertroom.jsp";
			} catch (HotelException e1) {

				e1.printStackTrace();
			}
			break;

		case "/deleteroom.do":

			String deleteroomId = request.getParameter("roomid");
			int deleteroomIdNum = Integer.parseInt(deleteroomId);
			hms = new AdminServiceImpl();
			int deleteroom;
			try {
				deleteroom = hms.deleteRoomDetails(deleteroomIdNum);
				if (deleteroom == 1) {
					ses.setAttribute("val1", ses.getAttribute("value"));
					request.setAttribute("delroomId", deleteroomId);
					request.setAttribute("deleteroomMsg", "insertedhotel");
					target = "successadminop.jsp";
				} else {
					request.setAttribute("eMsg", "Wrong Room ID given");
					target = "deleteroom.jsp";
				}
			} catch (HotelException e) {
				request.setAttribute("eMsg", e.getMessage());
				target = "hotelerror.jsp";
			}
			break;
		case "/updateroom.do":

			break;

		case "/updateHotel.do":

			hms = new AdminServiceImpl();
			int upHotelId = Integer.parseInt(request.getParameter("hotelid"));
			String updateCity = request.getParameter("city");
			String updateHotelName = request.getParameter("hotelname");
			String updateAddress = request.getParameter("address");
			String updateDescription = request.getParameter("description");
			String updateRate = request.getParameter("avgpernight");
			String updatePhone1 = request.getParameter("phone1");
			String updatePhone2 = request.getParameter("phone2");
			String updateRating = request.getParameter("rating");
			String updateFax = request.getParameter("fax");
			String updateEmail = request.getParameter("email");
			request.setAttribute("checkmsg", "abc");
			if (!updateCity.equals("")) {
				try {
					if (hms.updateCity(updateCity, upHotelId)) {
						request.setAttribute("cityMsg", "City updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			if (!updateHotelName.equals("")) {
				try {
					if (hms.updateHotelName(updateHotelName, upHotelId)) {
						request.setAttribute("nameMsg", "HotelName updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			/*
			 * else{ request.setAttribute("nameMsg", null);
			 * target="updatehotel.jsp"; }
			 */
			if (!updateAddress.equals("")) {
				try {
					if (hms.updateHAddress(updateAddress, upHotelId)) {
						request.setAttribute("addressMsg", "Address updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			if (!updateDescription.equals("")) {
				try {
					if (hms.updateHDescription(updateDescription, upHotelId)) {
						request.setAttribute("descMsg", "Description updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}

			if (!updateRate.equals("")) {
				try {
					Float updateRatePrice = Float.parseFloat(updateRate);
					if (hms.updateHRate(updateRatePrice, upHotelId)) {
						request.setAttribute("priceMsg", "RatePrice updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}

			if (!updatePhone1.equals("")) {
				long newph1 = Long.parseLong(updatePhone1);
				try {
					if (hms.updateHPhone1(newph1, upHotelId)) {
						request.setAttribute("ph1Msg", "Phone1 updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}

			if (!updatePhone2.equals("")) {
				long newph2 = Long.parseLong(updatePhone2);
				try {
					if (hms.updateHPhone2(newph2, upHotelId)) {
						request.setAttribute("ph2Msg", "Phone2 updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			if (!updateEmail.equals("")) {
				try {
					if (hms.updateHEmail(updateEmail, upHotelId)) {
						request.setAttribute("emailMsg", "Email updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			if (!updateRating.equals("")) {
				try {
					if (hms.updateHRating(updateRating, upHotelId)) {
						request.setAttribute("ratingMsg", "Rating updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			if (!updateFax.equals("")) {
				try {
					if (hms.updateFax(Long.parseLong(updateFax), upHotelId)) {
						request.setAttribute("faxMsg", "Fax updated");
						target = "updatehotel.jsp";
					}
				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			break;

		case "/updateRoom.do":

			hms = new AdminServiceImpl();
			int updateroomid = Integer.parseInt(request.getParameter("roomid"));
			String updateroomno = request.getParameter("roomnum");
			String updateroomtype = request.getParameter("roomtype");
			String updateroomnightrate = request.getParameter("avgpernight");
			String updateavail = request.getParameter("avail");

			if (!updateroomno.equals("")) {
				try {
					if (hms.updateRoomNo(updateroomno, updateroomid)) {
						request.setAttribute("updateroomMsg", "update");
						target = "updateroom.jsp";
					}

				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			if (!updateroomtype.equals("")) {
				try {
					if (hms.updateRoomType(updateroomtype, updateroomid)) {
						request.setAttribute("updateroomtypeMsg", "update");
						target = "updateroom.jsp";
					}

				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			if (!updateroomnightrate.equals("")) {
				try {
					if (hms.updateNightRate(
							Float.parseFloat(updateroomnightrate), updateroomid)) {
						request.setAttribute("updatenightrateMsg", "update");
						target = "updateroom.jsp";
					}

				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			if (!updateavail.equals("")) {
				try {
					if (hms.updateAvailability(updateavail, updateroomid)) {
						request.setAttribute("updateroomavailMsg", "update");
						target = "updateroom.jsp";
					}

				} catch (HotelException e) {

					e.printStackTrace();
				}
			}
			break;

		case "/viewallhotels.do":

			hms = new AdminServiceImpl();
			ArrayList<Hotels> hotelList = null;
			ses.setAttribute("val1", ses.getAttribute("value"));
			// request.setAttribute("hotelList", hotelList);
			System.out.println("in controller");
			try {
				hotelList = hms.fetchAllHotels();
				if (hotelList != null) {
					System.out.println("show hotels");
					request.setAttribute("hotelList", hotelList);
					System.out.println("show hotels");
					request.setAttribute("viewhotelmsg", "viewAllHotels");
					System.out.println("show hotels");
					// ses.setAttribute("value1","value1");
					target = "successadminop.jsp";
				} else {
					request.setAttribute("viewhotelmsg", null);
					target = "successadminop.jsp";
				}
			} catch (HotelException e2) {

				request.setAttribute("eMsg", e2.getMessage());
				target = "hotelerror.jsp";
			}

			break;

		case "/viewspecifichotel.do":

			hms = new AdminServiceImpl();
			int specifichotelId = Integer.parseInt(request
					.getParameter("hotelid"));
			ArrayList<BookingDetails> specificHotelList;
			try {
				specificHotelList = hms.fetchBookingsbyHotelId(specifichotelId);
				ses.setAttribute("val1", ses.getAttribute("value"));
				if (specificHotelList != null) {
					request.setAttribute("specificHotelList", specificHotelList);
					request.setAttribute("viewbookingsmsg",
							"view all bookings in a specific hotel");
					target = "successadminop.jsp";
				} else {
					request.setAttribute("viewbookingsmsg", null);
					target = "successadminop.jsp";
				}
			} catch (HotelException e1) {

				e1.printStackTrace();
			}

			break;

		case "/viewguestlist.do":

			hms = new AdminServiceImpl();
			int guesthotelId = Integer
					.parseInt(request.getParameter("hotelid"));
			ArrayList<Users> viewGuestList = null;
			try {
				viewGuestList = hms.fetchGuestNamesbyHotelId(guesthotelId);
				ses.setAttribute("val1", ses.getAttribute("value"));
				if (viewGuestList != null) {
					request.setAttribute("viewGuestList", viewGuestList);
					request.setAttribute("viewguestlistmsg",
							"view guest list in a specific hotel");
					target = "successadminop.jsp";
				} else {
					request.setAttribute("viewguestlistmsg", null);
					target = "successadminop.jsp";
				}
			} catch (HotelException e) {

				e.printStackTrace();
			}
			break;
		case "/viewbydate.do":

			break;
		case "/hotelid.do":
			System.out.println("selected");
			hms = new AdminServiceImpl();
			System.out.println("selected");
			int hotel_id = Integer.parseInt(request.getParameter("hotelid"));
			ArrayList<RoomDetails> list = null;
			System.out.println("selected");
			try {
				list = hms.selectRoomId(hotel_id);
				System.out.println("selected");

				request.setAttribute("roomlist", list);
				target = "updateroom.jsp";

			} catch (HotelException e) {

				e.printStackTrace();
			}
			break;

			// CUSTOMER OPERATIONS

		case "/register.do":
			String uname = request.getParameter("uname");
			String upassword = request.getParameter("upassword");
			long umobile = Long.parseLong(request.getParameter("umobile"));
			long uphone = Long.parseLong(request.getParameter("uphone"));
			String uaddress = request.getParameter("uaddress");
			String uemail = request.getParameter("uemail");
			cserv = new CustomerServiceImpl();
			Users newuser = new Users(upassword, uname, umobile, uphone,
					uaddress, uemail);
			try {
				int userid = cserv.registerNewUser(newuser);
				if (userid != 0) {
					request.setAttribute("userid", userid);
					target = "index.jsp";
				}
			} catch (HotelException e) {

				e.printStackTrace();
			}
			break;
			/*
			 * case "/searchHotel.do": String sCity=request.getParameter("city");
			 * cserv=new CustomerServiceImpl(); try { ArrayList<Hotels>
			 * searchHotelList=cserv.showHotelDetailsByCity(sCity);
			 * request.setAttribute("searchHotel", searchHotelList);
			 * ArrayList<Hotels> addressList=cserv.showHotelDetailsByCity(sCity);
			 * request.setAttribute("addressList", addressList); ArrayList<Hotels>
			 * rateList=cserv.showHotelDetailsByCity(sCity);
			 * request.setAttribute("rateList", rateList);
			 * target="aftercityentered.jsp"; } catch (HotelException e) { // TODO
			 * Auto-generated catch block e.printStackTrace(); } break;
			 */
		case "/searchHotelAddressRate.do":
			String sCityRating = request.getParameter("city");
			String searchRating = request.getParameter("rate");
			String searchAddress = request.getParameter("address");
			cserv = new CustomerServiceImpl();

			/*
			 * ArrayList<String> cityList2;
			 * 
			 * 
			 * ArrayList<Float> addressRateList;
			 * System.out.println("in controller 1"); try { cityList2 =
			 * cserv.showdistinctcity(); request.setAttribute("cityList",
			 * cityList2); System.out.println("in controller 2");
			 * 
			 * rateList=cserv.showRateAddress(sCityRating, searchAddress);
			 * request.setAttribute("rateList", rateList);
			 * System.out.println("in controller 3");
			 * addressRateList=cserv.showRateCity(sCityRating);
			 * request.setAttribute("addressRateList", addressRateList);
			 * System.out.println("in controller 4");
			 * searchHotelList=cserv.showHotelDetailsByCity(sCityRating);
			 * request.setAttribute("searchHtlLst", searchHotelList); } catch
			 * (HotelException e1) { // TODO Auto-generated catch block
			 * System.out.println("catch 1"); e1.printStackTrace(); }
			 */
			System.out.println("in controller 5");

			System.out.println("in controller 6");
			if (!searchRating.equals("") && !searchAddress.equals("")) {
				try {
					searchHotelList = cserv.showHotelDetailsByCityAddAndRate(
							sCityRating, searchAddress,
							Float.parseFloat(searchRating));
					request.setAttribute("searchHotel", searchHotelList);
					ArrayList<Float> rateList = cserv.showRateAddress(
							sCityRating, searchAddress);
					request.setAttribute("rateList", rateList);
					target = "aftercityentered.jsp";
				} catch (HotelException e) {
					System.out.println("catch 2");
					e.printStackTrace();
				}
			}
			if (!searchRating.equals("")) {
				try {
					searchHotelList = cserv.showHotelDetailsByCityAndRate(
							sCityRating, Float.parseFloat(searchRating));
					request.setAttribute("searchHotel", searchHotelList);

					target = "aftercityentered.jsp";
				} catch (HotelException e) {
					System.out.println("catch 3");
					e.printStackTrace();
				}
			}
			if (!searchAddress.equals("")) {
				try {
					searchHotelList = cserv.showHotelDetailsByAddress(
							sCityRating, searchAddress);
					request.setAttribute("searchHotel", searchHotelList);
					ArrayList<String> addressList = cserv
							.showAddress(sCityRating);
					request.setAttribute("addressList", addressList);
					target = "aftercityentered.jsp";
				} catch (HotelException e) {
					System.out.println("catch 4");
					e.printStackTrace();
				}
			}
			if (!sCityRating.equals("")) {
				try {
					ArrayList<String> cityList2 = cserv.showdistinctcity();
					request.setAttribute("cityList", cityList2);
					target = "aftercityentered.jsp";

				} catch (HotelException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			break;
		case "/bookingpage.do":
			String hotid = request.getParameter("hid");
			cserv = new CustomerServiceImpl();
			try {
				Hotels hotlist = cserv.showRateCity(Integer.parseInt(hotid));
				request.setAttribute("hotel", hotlist);
				target = "bookingpage.jsp";
			} catch (HotelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			break;
		case "/bookingRoom.do":

			try {
				String hotelId = request.getParameter("hotelid");
				
				String bookedto = request.getParameter("todate");
				System.out.println(bookedto+"****");
				/*SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date date = sdf1.parse(bookedto);
				java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());*/
				String roomtype1 = request.getParameter("roomtype");
				ses.setAttribute("usernm", ses.getAttribute("userid"));
				System.out.println( ses.getAttribute("userid"));
				System.out
				.println(roomtype1 + " " + bookedto + " " + hotelId);
				hms = new AdminServiceImpl();

				if (!(request.getParameter("todate").equals(""))) {
					// if(new java.sql.Date(currentTime).compareTo(sqlEndDate) >
					// 0)
					// {
					room = hms.checkRoomAvail(roomtype1,
							Integer.parseInt(hotelId));
					int count = hms.showAvailCount(roomtype1,
							Integer.parseInt(hotelId));
					System.out.println(count);
					//if (room != null) {
						if (count > 0) {
							request.setAttribute("bookedto", bookedto);
							request.setAttribute("roomtype1", roomtype1);
							request.setAttribute("room", room);
							request.setAttribute("count", count);
							request.setAttribute("hotelid", hotelId);
							System.out.println(count);
							request.setAttribute("todate",
									request.getParameter("todate"));

							target = "noOfRoomsDetails.jsp";
						} else {
							request.setAttribute("roommsg", null);
							target = "bookingpage.jsp";
						//}
					}
					// }

				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			break;
		case "/booking.do":
			int userId = Integer.parseInt(request.getParameter("userid"));
			System.out.println(userId);
			int noOfAdult = Integer.parseInt(request.getParameter("noofadults"));
			int noOfChild = Integer.parseInt(request.getParameter("noofkids"));
			int noOfRooms = Integer.parseInt(request.getParameter("noofrooms"));
			float roomPrice = Float.parseFloat(request.getParameter("price"));
			//int roomId1 = Integer.parseInt(request.getParameter("roomid"));
			String date2=request.getParameter("booked_to");
			System.out.println("111111   "+date2);
			String roomtype1 = request.getParameter("roomtype1");
			int htlid=Integer.parseInt(request.getParameter("hotel_id"));
			cserv = new CustomerServiceImpl();
			if (noOfAdult != 0 && noOfChild != 0) {
				if (noOfAdult >= noOfChild) {
					int result = 0;
					int quotient = noOfAdult % 2;
					int remainder = noOfAdult / 2;
					result = quotient + remainder;
					if (noOfRooms >= result) {
						float totalAmount = roomPrice * noOfRooms;
						System.out.println(result);
						BookingDetails book = new BookingDetails(userId,date2,noOfAdult, noOfChild, totalAmount);
						try {
							
							int bookingId = cserv.insertBookingdetails(htlid,roomtype1,book,noOfRooms);
							System.out.println("controller");
							request.setAttribute("book", book);
							request.setAttribute("bookingId", bookingId);
							request.setAttribute("totalAmount", totalAmount);
							target = "successpage.jsp";
						} catch (HotelException e) {

							e.printStackTrace();
						}

					} else {
						request.setAttribute("msg", "Choose" + result + "rooms");
						target = "noOfRoomsDetails.jsp";
					}

				} else if (noOfAdult < noOfChild) {
					int result = 0;
					int quotient = noOfChild % 2;
					int remainder = noOfChild / 2;
					result = quotient + remainder;
					if (noOfRooms >= result) {
						float totalAmount = roomPrice * noOfRooms;
						System.out.println(result);
						BookingDetails book = new BookingDetails(
								userId,date2, noOfAdult, noOfChild, totalAmount);
						int bookingId;
						try {
							bookingId = cserv.insertBookingdetails(htlid,roomtype1,book,noOfRooms);
							System.out.println("controller");
							request.setAttribute("book", book);
							request.setAttribute("bookingId", bookingId);
							request.setAttribute("totalAmount", totalAmount);
							target = "successpage.jsp";
						} catch (HotelException e) {

							e.printStackTrace();
						}

					} else {
						request.setAttribute("msg", "Choose" + result + "rooms");
						target = "noOfRoomsDetails.jsp";
					}
				}

			} else if (noOfAdult != 0) {
				int result = 0;
				int quotient = noOfAdult % 2;
				int remainder = noOfAdult / 2;
				result = quotient + remainder;
				if (noOfRooms >= result) {
					float totalAmount = roomPrice * noOfRooms;
					System.out.println(result);
					BookingDetails book = new BookingDetails(userId,date2,
							noOfAdult, noOfChild, totalAmount);
					int bookingId;
					try {
						bookingId = cserv.insertBookingdetails(htlid,roomtype1,book,noOfRooms);
						System.out.println("controller");
						request.setAttribute("book", book);
						request.setAttribute("bookingId", bookingId);
						request.setAttribute("totalAmount", totalAmount);
						target = "successpage.jsp";
					} catch (HotelException e) {

						e.printStackTrace();
					}

				} else {
					request.setAttribute("msg", "Choose" + result + "rooms");
					target = "noOfRoomsDetails.jsp";
				}
			}
			break;

		case "/logout.do":
			ses.invalidate();
			response.sendRedirect("index.jsp");
			break;
		default:
		}
		request.getRequestDispatcher(target).forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}
}
