package com.cg.hms.service;

import java.util.ArrayList;

import com.cg.hms.bean.BookingDetails;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.Users;
import com.cg.hms.exception.HotelException;

public interface ICustomerService {
public int registerNewUser(Users user) throws HotelException;
	
	public int generateUserId() throws HotelException;
	
	public ArrayList<Hotels> showHotelDetailsByCity(String city) throws HotelException;

	public ArrayList<Hotels> showHotelDetailsByAddress(String city,String address) throws HotelException;

	public ArrayList<Hotels> showHotelDetailsByRating(String city,String rating) throws HotelException;

	public ArrayList<Hotels> showHotelDetailsByCityNameAndAdd(String city,String rating, String address) throws HotelException;

	public ArrayList<Hotels> showHotelDetailsByCityAddAndRate(String city,String address, float rate) throws HotelException;
	
	public ArrayList<Hotels> showHotelDetailsByCityAndRate(String city,Float rate) throws HotelException;
	
	public BookingDetails viewBookingDetails(int bookingid) throws HotelException;

	public int insertBookingdetails(int hotelid,String roomtype,BookingDetails bookingdetails,int roomNum) throws HotelException;
	
	public int generateRoomId() throws HotelException;
	
	public int generateBookingId() throws HotelException;
	
public ArrayList<String> showdistinctcity() throws HotelException;
	
	public ArrayList<String> showAddress(String city) throws HotelException; 
	
	public ArrayList<Float> showRateAddress(String city,String address) throws HotelException; 
	
	public ArrayList<Float> showRateCity(String city) throws HotelException;
	
	public Hotels showRateCity(int hotelId) throws HotelException;
	
	
}
