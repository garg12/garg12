package com.cg.hms.service;

import java.util.ArrayList;

import com.cg.hms.bean.BookingDetails;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.Users;
import com.cg.hms.dao.AdminDAOImpl;
import com.cg.hms.dao.CustomerDAOImpl;
import com.cg.hms.dao.IAdminDAO;
import com.cg.hms.dao.ICustomerDAO;
import com.cg.hms.exception.HotelException;

public class CustomerServiceImpl implements ICustomerService{
	ICustomerDAO cusdao=null;
	IAdminDAO admdao=null;
	@Override
	public int registerNewUser(Users user) throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.registerNewUser(user);
	}

	@Override
	public int generateUserId() throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.generateUserId();
	}

	@Override
	public ArrayList<Hotels> showHotelDetailsByCity(String city)
			throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showHotelDetailsByCity(city);
	}

	@Override
	public ArrayList<Hotels> showHotelDetailsByAddress(String city,
			String address) throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showHotelDetailsByAddress(city, address);
	}

	@Override
	public ArrayList<Hotels> showHotelDetailsByRating(String city, String rating)
			throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showHotelDetailsByRating(city, rating);
	}

	@Override
	public ArrayList<Hotels> showHotelDetailsByCityNameAndAdd(String city,
			String rating, String address) throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showHotelDetailsByCityNameAndAdd(city, rating, address);
	}

	@Override
	public ArrayList<Hotels> showHotelDetailsByCityAddAndRate(String city,
			String address, float rate) throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showHotelDetailsByCityAddAndRate(city, address, rate);
	}

	@Override
	public ArrayList<Hotels> showHotelDetailsByCityAndRate(String city,
			Float rate) throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showHotelDetailsByCityAndRate(city, rate);
	}

	@Override
	public BookingDetails viewBookingDetails(int bookingid)
			throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.viewBookingDetails(bookingid);
	}

	@Override
	public int insertBookingdetails(int hotelid,String roomtype,BookingDetails bookingdetails,int roomNum)
			throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.insertBookingdetails(hotelid,roomtype,bookingdetails,roomNum);
	}

	@Override
	public int generateRoomId() throws HotelException {
		admdao=new AdminDAOImpl();
		return admdao.generateRoomId();
	}

	@Override
	public int generateBookingId() throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.generateBookingId();
	}

	@Override
	public ArrayList<String> showdistinctcity() throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showdistinctcity();
	}

	@Override
	public ArrayList<String> showAddress(String city) throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showAddress(city);
	}

	@Override
	public ArrayList<Float> showRateAddress(String city, String address)
			throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showRateAddress(city, address);
	}

	@Override
	public ArrayList<Float> showRateCity(String city) throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showRateCity(city);	}

	@Override
	public Hotels showRateCity(int hotelId) throws HotelException {
		cusdao=new CustomerDAOImpl();
		return cusdao.showRateCity(hotelId);
	}

}
