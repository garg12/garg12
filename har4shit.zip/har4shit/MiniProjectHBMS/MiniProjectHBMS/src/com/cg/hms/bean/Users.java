package com.cg.hms.bean;

public class Users {

	private int user_id;
	private String password;
	private String role;
	private String user_name;
	private long mobile_no;
	private long phone;
	private String address;
	private String email;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public long getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(long mobile_no) {
		this.mobile_no = mobile_no;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Users [user_id=" + user_id + ", password=" + password
				+ ", role=" + role + ", user_name=" + user_name
				+ ", mobile_no=" + mobile_no + ", phone=" + phone
				+ ", address=" + address + ", email=" + email + "]";
	}
	public Users(int user_id, String password, String role,
			String user_name, long mobile_no, long phone, String address,
			String email) {
		super();
		this.user_id = user_id;
		this.password = password;
		this.role = role;
		this.user_name = user_name;
		this.mobile_no = mobile_no;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Users(String user_name) {
		super();
		this.user_name = user_name;
	}
	public Users(String password, String user_name, long mobile_no, long phone,
			String address, String email) {
		super();
		this.password = password;
		this.user_name = user_name;
		this.mobile_no = mobile_no;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	
}
