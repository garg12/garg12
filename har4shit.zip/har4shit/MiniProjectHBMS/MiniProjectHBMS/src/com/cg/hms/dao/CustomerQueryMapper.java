package com.cg.hms.dao;

public class CustomerQueryMapper 
{
	//register into the system
	public static final String INSERTQRY="INSERT INTO Users VALUES"
			+ "(?,?,'customer',?,?,?,?,?)";
	public static final String GENUSERIDQUERY="SELECT SEQ_userId.NEXTVAL FROM DUAL";
	//login to the system
	public static final String SHOWHOTELCITIES="SELECT DISTINCT city FROM HOTELS";
	//search for hotel rooms by city
	public static final String SEARCHHOTELQRY1="SELECT * FROM HOTELS WHERE CITY=?";
	//search for hotels by city and address
	public static final String SEARCHHOTELBYCITYANDADD="SELECT * FROM HOTELS WHERE city=? AND address=? AND avg_rate_per_night=?";
	//search for hotels by city, address and rate per night
	public static final String SEARCHHOTELBYCITYADDRESSRATE="SELECT * FROM HOTELS WHERE city=? AND address=? AND rating=?";
	//search for hotels by city and rate per night
	public static final String SEARCHHOTELBYCITYANDRATE="SELECT * FROM HOTELS WHERE city=? AND avg_rate_per_night=?";
	//search for hotel rooms by hotel name
	public static final String SEARCHHOTELQRY2="SELECT * FROM HOTELS WHERE city=? and address=?";
	//search for hotel rooms by rating
	public static final String SEARCHHOTELQRY4="SELECT * FROM HOTELS WHERE city=? and rating=?";
	//view booking status
	public static final String VIEWBOOKINGQRY="SELECT * FROM bookingdetails WHERE booking_id=?";
	//book hotel rooms
	public static final String INSERTBOOKINGDETAILS="INSERT INTO bookingdetails (booking_id,room_id,user_id,booked_to,no_of_adults,no_of_children,amount,booked_from) VALUES (?,?,?,?,?,?,?,sysdate)";	
	
	public static final String SHOWADDRESSONCITY="SELECT ADDRESS FROM HOTELS WHERE CITY=?";
	
	public static final String SHOWRATEADDRESSONCITY="SELECT avg_rate_per_night FROM HOTELS WHERE CITY=? AND ADDRESS=?";
	
	public static final String SHOWRATEONCITY="SELECT avg_rate_per_night FROM HOTELS WHERE CITY=?";
	
	public static final String SHOWHOTELID="SELECT * FROM HOTELS WHERE HOTEL_ID=?";
	
	public static final String selectRoomIdQuery="SELECT room_id from roomdetails where hotel_id=? and room_type=? and availability='Yes'";
	
}
