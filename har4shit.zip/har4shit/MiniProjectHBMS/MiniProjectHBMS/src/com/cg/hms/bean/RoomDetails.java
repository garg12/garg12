package com.cg.hms.bean;

import java.sql.Blob;

public class RoomDetails 
{
	private int room_id;
	public RoomDetails(int room_id) {
		super();
		this.room_id = room_id;
	}
	private int hotel_id;
	private String room_no;
	private String romm_type;
	private float per_night_rate;
	private String availability;
	public RoomDetails(int room_id, int hotel_id, String room_no,
			String romm_type, float per_night_rate, String availability,
			Blob photo) {
		super();
		this.room_id = room_id;
		this.hotel_id = hotel_id;
		this.room_no = room_no;
		this.romm_type = romm_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;	
	}
	public RoomDetails() {
		super();
	}
	public int getRoom_id() {
		return room_id;
	}
	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}
	public int getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}
	public String getRoom_no() {
		return room_no;
	}
	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}
	public String getRomm_type() {
		return romm_type;
	}
	public void setRomm_type(String romm_type) {
		this.romm_type = romm_type;
	}
	public float getPer_night_rate() {
		return per_night_rate;
	}
	public void setPer_night_rate(float per_night_rate) {
		this.per_night_rate = per_night_rate;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	
	
	@Override
	public String toString() {
		return "RoomDetails [room_id=" + room_id + ", hotel_id=" + hotel_id
				+ ", room_no=" + room_no + ", romm_type=" + romm_type
				+ ", per_night_rate=" + per_night_rate + ", availability="
				+ availability + "]";
	}
	public RoomDetails(int hotel_id, String room_no, String romm_type,
			float per_night_rate, String availability) {
		super();
		this.hotel_id = hotel_id;
		this.room_no = room_no;
		this.romm_type = romm_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;
	}
	public RoomDetails(int room_id, int hotel_id, String room_no,
			String romm_type, float per_night_rate, String availability) {
		super();
		this.room_id = room_id;
		this.hotel_id = hotel_id;
		this.room_no = room_no;
		this.romm_type = romm_type;
		this.per_night_rate = per_night_rate;
		this.availability = availability;
	}
	public RoomDetails(float per_night_rate, String availability) {
		super();
		this.per_night_rate = per_night_rate;
		this.availability = availability;
	}
	
}
