package com.cg.hms.service;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.hms.bean.BookingDetails;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomDetails;
import com.cg.hms.bean.Users;
import com.cg.hms.dao.AdminDAOImpl;
import com.cg.hms.dao.IAdminDAO;
import com.cg.hms.exception.HotelException;

public class AdminServiceImpl implements IAdminService{
	IAdminDAO admindao=null;
	@Override
	public String isRoleAdmin(int adminusername, String adminpassword)
			throws HotelException {
		admindao=new AdminDAOImpl();
		System.out.println("In service");
		return admindao.isRoleAdmin(adminusername, adminpassword);
	}

	@Override
	public int generateHotelId() throws HotelException {

		admindao=new AdminDAOImpl();
		return admindao.generateHotelId();
	}

	@Override
	public int generateRoomId() throws HotelException {

		admindao=new AdminDAOImpl();
		return admindao.generateRoomId();
	}

	@Override
	public int addHotelDetails(Hotels hotel) throws HotelException {

		admindao=new AdminDAOImpl();
		System.out.println("In service");
		return admindao.addHotelDetails(hotel);
	}

	@Override
	public int deleteHotelDetails(int hotelId) throws HotelException {

		admindao=new AdminDAOImpl();
		return admindao.deleteHotelDetails(hotelId);
	}

	@Override
	public int addRoomDetails(RoomDetails rmdtls) throws HotelException {

		admindao=new AdminDAOImpl();
		return admindao.addRoomDetails(rmdtls);
	}

	@Override
	public int deleteRoomDetails(int roomId) throws HotelException {

		admindao=new AdminDAOImpl();
		return admindao.deleteRoomDetails(roomId);
	}

	@Override
	public ArrayList<Hotels> selectHotelId() throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.selectHotelId();
	}

	@Override
	public ArrayList<Hotels> fetchAllHotels() throws HotelException {
		admindao=new AdminDAOImpl();
		System.out.println("In service");
		return admindao.fetchAllHotels();
	}

	@Override
	public ArrayList<BookingDetails> fetchBookingsbyHotelId(int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.fetchBookingsbyHotelId(hotelId);
	}

	@Override
	public ArrayList<Users> fetchGuestNamesbyHotelId(int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.fetchGuestNamesbyHotelId(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> fetchBookingsByDate(Date bookingdate)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.fetchBookingsByDate(bookingdate);
	}

	@Override
	public boolean updateCity(String city, int hotelId) throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateCity(city, hotelId);
	}

	@Override
	public boolean updateHotelName(String hotelName, int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateHotelName(hotelName, hotelId);
	}

	@Override
	public boolean updateHAddress(String address, int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateHAddress(address, hotelId);
	}

	@Override
	public boolean updateHDescription(String description, int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateHDescription(description, hotelId);
	}

	@Override
	public boolean updateHRate(float rate, int hotelId) throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateHRate(rate, hotelId);
	}

	@Override
	public boolean updateHPhone1(long phone1, int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateHPhone1(phone1, hotelId);
	}

	@Override
	public boolean updateHPhone2(long phone2, int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateHPhone2(phone2, hotelId);
	}

	@Override
	public boolean updateHRating(String rating, int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateHRating(rating, hotelId);
	}

	@Override
	public boolean updateHEmail(String email, int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateHEmail(email, hotelId);
	}

	@Override
	public boolean updateFax(long fax, int hotelId) throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateFax(fax, hotelId);
	}

	@Override
	public boolean updateRoomNo(String roomno, int roomid)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateRoomNo(roomno, roomid);
	}

	@Override
	public boolean updateRoomType(String roomtype, int roomid)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateRoomType(roomtype, roomid);
	}

	@Override
	public boolean updateNightRate(float pnr, int roomid)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateNightRate(pnr, roomid);
	}

	@Override
	public boolean updateAvailability(String avail, int roomid)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.updateAvailability(avail, roomid);
	}

	@Override
	public ArrayList<Hotels> fetchAllHotelById(int hotelid) throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.fetchAllHotelById(hotelid);
	}

	@Override
	public ArrayList<RoomDetails> selectRoomId(int hotelId)
			throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.selectRoomId(hotelId);
	}

	@Override
	public RoomDetails checkAvailability(Date booked_from_date,
			String booked_to_date, String room_type) throws HotelException {
		admindao=new AdminDAOImpl();
		return admindao.checkAvailability(booked_from_date, booked_to_date, room_type);
	}

	@Override
	public void updateAvailability1(int roomid)
			throws HotelException {
		admindao=new AdminDAOImpl();
	}

	@Override
	public void updateNewAvailability(String booked_to_date)
			throws HotelException {
		admindao=new AdminDAOImpl();	
	}

	@Override
	public int showAvailCount(String room_type, int hotelid)
			throws HotelException {
		admindao=new AdminDAOImpl();	
		return admindao.showAvailCount(room_type, hotelid);
	}

	@Override
	public RoomDetails checkRoomAvail(String room_type, int hotelid)
			throws HotelException {
		admindao=new AdminDAOImpl();	
		return admindao.checkRoomAvail(room_type, hotelid);
	}
}
