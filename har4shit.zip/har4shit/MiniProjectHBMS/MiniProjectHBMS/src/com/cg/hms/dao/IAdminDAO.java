package com.cg.hms.dao;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.hms.bean.BookingDetails;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomDetails;
import com.cg.hms.bean.Users;
import com.cg.hms.exception.HotelException;

public interface IAdminDAO {
	public String isRoleAdmin(int adminusername,String adminpassword) 
			throws HotelException;
	public int generateHotelId() throws HotelException; 
	public int generateRoomId() throws HotelException;
	public int addHotelDetails(Hotels hotel) throws HotelException;
	public int deleteHotelDetails(int hotelId) throws HotelException;
	public int addRoomDetails(RoomDetails rmdtls) throws HotelException;
	public int deleteRoomDetails(int roomId) throws HotelException;
	public ArrayList<Hotels> selectHotelId() throws HotelException;
	public ArrayList<Hotels> fetchAllHotels() throws HotelException;
	public ArrayList<BookingDetails> fetchBookingsbyHotelId(int hotelId) throws HotelException;
	public ArrayList<Users> fetchGuestNamesbyHotelId(int hotelId) throws HotelException;
	public ArrayList<BookingDetails> fetchBookingsByDate(Date bookingdate) throws HotelException;
	public ArrayList<Hotels> fetchAllHotelById(int hotelid) throws HotelException;
	public boolean updateCity(String city,int hotelId) throws HotelException;
	public boolean updateHotelName(String hotelName,int hotelId) throws HotelException;
	public boolean updateHAddress(String address,int hotelId) throws HotelException;
	public boolean updateHDescription(String description,int hotelId) throws HotelException;
	public boolean updateHRate(float rate,int hotelId) throws HotelException;
	public boolean updateHPhone1(long phone1,int hotelId) throws HotelException;
	public boolean updateHPhone2(long phone2,int hotelId) throws HotelException;
	public boolean updateHRating(String rating,int hotelId) throws HotelException;
	public boolean updateHEmail(String email,int hotelId) throws HotelException;
	public boolean updateFax(long fax,int hotelId) throws HotelException;
	public boolean updateRoomNo(String roomno,int roomid) throws HotelException;
	public boolean updateRoomType(String roomtype,int roomid) throws HotelException;
	public boolean updateNightRate(float pnr,int roomid) throws HotelException;
	public boolean updateAvailability(String avail,int roomid) throws HotelException;
	public ArrayList<RoomDetails> selectRoomId(int hotelId) throws HotelException;
	public RoomDetails checkAvailability(Date booked_from_date,String booked_to_date,String room_type) throws HotelException;
	public void updateAvailability1(int roomid) throws HotelException;
	public void updateNewAvailability(Date booked_to_date) throws HotelException; 
	public RoomDetails checkRoomAvail(String room_type,int hotelid) throws HotelException; 
	public int showAvailCount(String room_type,int hotelid) throws HotelException;
}
