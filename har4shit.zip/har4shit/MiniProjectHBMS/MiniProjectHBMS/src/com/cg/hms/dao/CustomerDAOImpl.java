package com.cg.hms.dao;


import java.sql.Connection;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.hms.dao.CustomerQueryMapper;
import com.cg.hms.bean.BookingDetails;
import com.cg.hms.bean.Hotels;
import com.cg.hms.bean.RoomDetails;
import com.cg.hms.bean.Users;
import com.cg.hms.exception.HotelException;
import com.cg.hms.util.DBUtil;

public class CustomerDAOImpl implements ICustomerDAO
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public int registerNewUser(Users user) throws HotelException
	{
		int userid=generateUserId();
		int dataInserted=0;
		try 
		{		
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.INSERTQRY);
			pst.setInt(1,userid);
			pst.setString(2, user.getPassword());
			pst.setString(3, user.getUser_name());
			pst.setLong(4, user.getMobile_no());
			pst.setLong(5, user.getPhone());
			pst.setString(6, user.getAddress());
			pst.setString(7, user.getEmail());
			dataInserted=pst.executeUpdate();
			if(dataInserted==0)
			{
				userid=0;
			}
		} catch (Exception e) {
			throw new HotelException(e.getMessage(),e.getCause());
		}
		return userid;

	}

	@Override
	public int generateUserId() throws HotelException{
		int generatedUserId=0;
		try {

			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(CustomerQueryMapper.GENUSERIDQUERY);
			rs.next();
			generatedUserId=rs.getInt(1);

		} catch (Exception e) {

			e.printStackTrace();
		}

		return generatedUserId;
	}
	//method to view all a booking details by booking id
	@Override
	public BookingDetails viewBookingDetails(int bookingid) throws HotelException  
	{
		BookingDetails bookingdetails=null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.VIEWBOOKINGQRY);
			pst.setInt(1,bookingid);
			rs=pst.executeQuery();
			rs.next();
			bookingdetails=new BookingDetails(rs.getInt("booking_id"),rs.getInt("room_id"),rs.getInt("user_id"),rs.getDate("booked_from"),rs.getString("booked_to"),rs.getInt("no_of_adults"),rs.getInt("no_of_children"),rs.getFloat("amount"));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return bookingdetails;
	}


	//method to insert booking details after a customer books a room
	@Override
	public int insertBookingdetails(int hotelid,String roomtype,BookingDetails bookingdetails,int roomNum) throws HotelException
	{
		int bookingid=generateBookingId();
		//RoomDetails rmd=new RoomDetails();
		int dataInserted=0;
		//int roomId=selectRoomId(rmd.getHotel_id(),rmd.getRomm_type());
		IAdminDAO adm=new AdminDAOImpl();
		System.out.println("rm tp "+roomtype);
		System.out.println("room num "+roomNum);
		try 
		{
			con=DBUtil.getCon();
			/*for(int count=0;count<roomNum;count++)
			{*/
				pst=con.prepareStatement(CustomerQueryMapper.INSERTBOOKINGDETAILS);
				pst.setInt(1,bookingid);
				pst.setInt(2,selectRoomId(hotelid,roomtype));
				//System.out.println("++++++"+selectRoomId(hotelid,roomtype));
				System.out.println("userid"+ bookingdetails.getUser_id());		
				pst.setInt(3,bookingdetails.getUser_id());	
				System.out.println("userid12  "+ bookingdetails.getUser_id());
				pst.setString(4, bookingdetails.getBooked_to());
				System.out.println("###########"+bookingdetails.getBooked_to());
				pst.setInt(5, bookingdetails.getNo_of_adults());
				pst.setInt(6, bookingdetails.getNo_of_children());
				pst.setFloat(7, bookingdetails.getAmount());
				dataInserted=pst.executeUpdate();
				System.out.println("executed");
				if(dataInserted!=0)
				{
					adm.updateAvailability1(bookingdetails.getRoom_id());
				}
				else
				{
					bookingid=0;
				}
			//}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return bookingid;
	}


	//method to generate booking id through sequence
	@Override
	public int generateBookingId() throws HotelException {
		int generatedBookingId=0;
		try {
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(AdminQueryMapper.bookingIdSequenceQuery);
			rs.next();
			generatedBookingId=rs.getInt(1);
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}

		return generatedBookingId;
	}
	//customer can view details of hotels by city
	@Override
	public ArrayList<Hotels> showHotelDetailsByCity(String city) throws HotelException 
	{
		Hotels hotel=null;
		ArrayList<Hotels> hotelList=new ArrayList<Hotels>();
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SEARCHHOTELQRY1);
			pst.setString(1,city);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hotel=new Hotels(rs.getInt("hotel_id"),rs.getString("city"),rs.getString("hotel_name"),rs.getString("address"),rs.getString("description"),rs.getFloat("avg_rate_per_night"),rs.getLong("phone_no1"),rs.getLong("phone_no2"),rs.getString("rating"),rs.getString("email"),rs.getLong("fax"));
				hotelList.add(hotel);
			}
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
		return hotelList;

	}

	//customer can view details of hotels by city and address
	@Override
	public ArrayList<Hotels> showHotelDetailsByAddress(String city,String address) throws HotelException
	{
		Hotels hotel=null;
		ArrayList<Hotels> hotelList=new ArrayList<Hotels>();
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SEARCHHOTELQRY2);
			pst.setString(1,city);
			pst.setString(2,address);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hotel=new Hotels(rs.getInt("hotel_id"),rs.getString("city"),rs.getString("hotel_name"),rs.getString("address"),rs.getString("description"),rs.getFloat("avg_rate_per_night"),rs.getLong("phone_no1"),rs.getLong("phone_no2"),rs.getString("rating"),rs.getString("email"),rs.getLong("fax"));
				hotelList.add(hotel);				
			}
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
		return hotelList;
	}



	//customer can view details of hotels by city, address and rate per night
	@Override
	public ArrayList<Hotels> showHotelDetailsByCityAddAndRate(String city,
			String address, float rate) throws HotelException
			{
		Hotels hotel=null;
		ArrayList<Hotels> hotelList=new ArrayList<Hotels>();
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SEARCHHOTELBYCITYANDADD);
			pst.setString(1,city);
			pst.setString(2,address);
			pst.setFloat(3,rate);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hotel=new Hotels(rs.getInt("hotel_id"),rs.getString("city"),rs.getString("hotel_name"),rs.getString("address"),rs.getString("description"),rs.getFloat("avg_rate_per_night"),rs.getLong("phone_no1"),rs.getLong("phone_no2"),rs.getString("rating"),rs.getString("email"),rs.getLong("fax"));
				hotelList.add(hotel);				
			}
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
		return hotelList;
			}
	//customer can view details of hotels by city, address and rating
	@Override
	public ArrayList<Hotels> showHotelDetailsByCityNameAndAdd(String city,
			String rating, String address) throws HotelException {
		Hotels hotel=null;
		ArrayList<Hotels> hotelList=new ArrayList<Hotels>();
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SEARCHHOTELBYCITYADDRESSRATE);
			pst.setString(1, city);
			pst.setString(2, address);
			pst.setString(3, rating);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hotel=new Hotels(rs.getInt("hotel_id"),rs.getString("city"),rs.getString("hotel_name"),rs.getString("address"),rs.getString("description"),rs.getFloat("avg_rate_per_night"),rs.getLong("phone_no1"),rs.getLong("phone_no2"),rs.getString("rating"),rs.getString("email"),rs.getLong("fax"));
				hotelList.add(hotel);				
			}
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
		return hotelList;
	}
	//generate room id using sequence
	@Override
	public int generateRoomId() throws HotelException {
		int generatedRoomId=0;
		try {
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(AdminQueryMapper.roomIDSequenceQuery);
			rs.next();
			generatedRoomId=rs.getInt(1);
		} catch (Exception e) {

			throw new HotelException(e.getMessage(),e.getCause());
		}
		return generatedRoomId;
	}
	//search hotels based on city and rating
	@Override
	public ArrayList<Hotels> showHotelDetailsByRating(String city,
			String rating) throws HotelException {
		Hotels hotel=null;
		ArrayList<Hotels> hotelList=new ArrayList<Hotels>();
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SEARCHHOTELQRY4);
			pst.setString(1, city);
			pst.setString(2, rating);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hotel=new Hotels(rs.getInt("hotel_id"),rs.getString("city"),rs.getString("hotel_name"),rs.getString("address"),rs.getString("description"),rs.getFloat("avg_rate_per_night"),rs.getLong("phone_no1"),rs.getLong("phone_no2"),rs.getString("rating"),rs.getString("email"),rs.getLong("fax"));
				hotelList.add(hotel);				
			}
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
		return hotelList;
	}
	//search hotels based on city and rate per night
	@Override
	public ArrayList<Hotels> showHotelDetailsByCityAndRate(String city,
			Float rate) throws HotelException {
		Hotels hotel=null;
		ArrayList<Hotels> hotelList=new ArrayList<Hotels>();
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SEARCHHOTELBYCITYANDRATE);
			pst.setString(1, city);
			pst.setFloat(2, rate);
			rs=pst.executeQuery();
			while(rs.next())
			{
				hotel=new Hotels(rs.getInt("hotel_id"),rs.getString("city"),rs.getString("hotel_name"),rs.getString("address"),rs.getString("description"),rs.getFloat("avg_rate_per_night"),rs.getLong("phone_no1"),rs.getLong("phone_no2"),rs.getString("rating"),rs.getString("email"),rs.getLong("fax"));
				hotelList.add(hotel);				
			}
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
		return hotelList;
	}

	@Override
	public ArrayList<String> showdistinctcity() {
		ArrayList<String> searchHotel=new ArrayList<String>();
		try {
			
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(CustomerQueryMapper.SHOWHOTELCITIES);
			while(rs.next())
			{
				searchHotel.add(rs.getString(1));
			}
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		return searchHotel;
	}

	@Override
	public ArrayList<String> showAddress(String city) throws HotelException {
		ArrayList<String> searchAddressHotel=new ArrayList<String>();
		try {
			
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SHOWADDRESSONCITY);
			pst.setString(1, city);
			rs=pst.executeQuery();
			while(rs.next())
			{
				searchAddressHotel.add(rs.getString("address"));
			}
		}
		
			catch(Exception e)
			{
				e.printStackTrace();
			}
		return searchAddressHotel;
	}

	@Override
	public ArrayList<Float> showRateAddress(String city, String address)
			throws HotelException {
		ArrayList<Float> searchrateaddHotel=new ArrayList<Float>();
		try {
			
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SHOWRATEADDRESSONCITY);
			pst.setString(1, city);
			pst.setString(2, address);
			rs=pst.executeQuery();
			while(rs.next())
			{
				searchrateaddHotel.add(rs.getFloat("avg_rate_per_night "));
			}
		}
		
			catch(Exception e)
			{
				e.printStackTrace();
			}
		return searchrateaddHotel;
	}

	@Override
	public ArrayList<Float> showRateCity(String city) throws HotelException {
		ArrayList<Float> searchrateHotel=new ArrayList<Float>();
		try {
			
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SHOWRATEONCITY);
			pst.setString(1, city);
			rs=pst.executeQuery();
			
			while(rs.next())
			{
				searchrateHotel.add(rs.getFloat("avg_rate_per_night"));
			}
		}
		
			catch(Exception e)
			{
				e.printStackTrace();
			}
		return searchrateHotel;
	}

	@Override
	public Hotels showRateCity(int hotelId) throws HotelException {
		
		Hotels hotel=null;
		try {
			
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.SHOWHOTELID);
			pst.setInt(1, hotelId);
			rs=pst.executeQuery();
			
			while(rs.next())
			{
				hotel=new Hotels(rs.getInt("hotel_id"),rs.getString("city"),
						rs.getString("hotel_name"),rs.getString("address"),
						rs.getString("description"),rs.getFloat("avg_rate_per_night"),
						rs.getLong("phone_no1"),rs.getLong("phone_no2"),
						rs.getString("rating"),rs.getString("email"),
						rs.getLong("fax"));
			}
		}
		
			catch(Exception e)
			{
				e.printStackTrace();
			}
		return hotel;
	}

	@Override
	public int selectRoomId(int hotelid, String roomtype)
			throws HotelException {
		int roomid=0;
		try {
			
			con=DBUtil.getCon();
			pst=con.prepareStatement(CustomerQueryMapper.selectRoomIdQuery);
			pst.setInt(1, hotelid);
			System.out.println("hotlid   "+hotelid);
			pst.setString(2, roomtype);
			System.out.println(" room type   "+ roomtype);
			rs=pst.executeQuery();
			while(rs.next())
			{
				roomid=rs.getInt("room_id");
				System.out.println("---------- "+roomid);
			}
		
		}
		
			catch(Exception e)
			{
				e.printStackTrace();
			}
		return roomid;
	}
	
	
	


}
