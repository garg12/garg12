package com.cg.hms.util;



import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.hms.exception.HotelException;
//import com.cg.ra.rechargeException.RechargeException;





public class DBUtil {
	public static Connection getCon() throws HotelException 
	{
		InitialContext ic=null;;
		Connection connection=null;
		DataSource ds=null;
		try {
			ic = new InitialContext();
			ds=(DataSource) ic.lookup("java:/OracleDS");
			connection=ds.getConnection();
		} catch (NamingException e) {
			throw new HotelException("message from DB/NamingExc:"+e.getMessage());		
		}
		catch (SQLException e) {
			throw new HotelException("SQL Error:"+e.getMessage());
		}
		return connection;	
	}

}
