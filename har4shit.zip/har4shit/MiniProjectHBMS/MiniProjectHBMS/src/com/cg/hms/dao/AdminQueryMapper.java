package com.cg.hms.dao;

public interface AdminQueryMapper {
	String adminLoginQuery           ="select user_id,password,role from USERS";
	String hotelIDSequenceQuery      ="SELECT SEQ_hotelId.NEXTVAL FROM DUAL";
	String adminAddHotelQuery        ="insert into HOTELS values(?,?,?,?,?,?,?,?,?,?,?)";
	String adminUpdateHotelQuery     ="update table HOTELS ";
	String adminDeleteHotelQuery     ="DELETE FROM HOTELS WHERE HOTEL_ID=?";
	String roomIDSequenceQuery       ="SELECT SEQ_roomId.NEXTVAL FROM DUAL";
	String adminAddRoomInfoQuery     ="insert into roomdetails values(?,?,?,?,?,?)";
	String adminDeleteRoomInfoQuery  ="DELETE FROM ROOMDETAILS WHERE ROOM_ID=?";
	String adminSelectHotelIdQuery   ="select hotel_id from hotels";
	String bookingIdSequenceQuery    ="select SEQ_bookingId.nextval from dual";
	String UPDATEHCITYQRY            ="update hotels set city=? where hotel_id=?";
	String UPDATEHADDRESSQRY         ="update hotels set address=? where hotel_id=?";
	String UPDATEHHOTELNAMEQRY       ="update hotels set hotel_name=? where hotel_id=?";
	String UPDATEHDESCQRY            ="update hotels set description=? where hotel_id=?";
	String UPDATEHRATEQRY            ="update hotels set avg_rate_per_night=? where hotel_id=?";
	String UPDATEHPHONE1QRY          ="update hotels set phone_no1=? where hotel_id=?";
	String UPDATEHPHONE2QRY          ="update hotels set phone_no2=? where hotel_id=?";
	String UPDATEHRATINGQRY          ="update hotels set rating=? where hotel_id=?";
	String UPDATEHEMAILQRY           ="update hotels set email=? where hotel_id=?";
	String UPDATEHFAXQRY             ="update hotels set fax=? where hotel_id=?";
	String UPDATEROOMNOQRY           ="update roomdetails set room_no=? where room_id=?";
	String UPDATEROOMTYPEQRY         ="update roomdetails set room_type=? where room_id=?";
	String UPDATEROOMNIGHTRATEQRY    ="update roomdetails set per_night_rate=? where room_id=?";
	String UPDATEROOMAVAILQRY        ="update roomdetails set availability=? where room_id=?";
	String adminViewAllHotelIdQuery  ="select * from hotels where hotel_id=?";
	String adminViewAllHotelsQuery   ="select * from hotels";
	String adminViewBookingsQuery    ="select booking_id,room_id,user_id,booked_from,"
			                         + " booked_to, no_of_adults,no_of_children,"
			                         + "amount from bookingdetails b,"
			                         + " roomdetails r, hotels h "
			                         + "where b.room_id=r.room_id and "
			                         + "r.hotel_id=h.hotel_id"
			                         + " and h.hotel_id=?  ";
	String adminViewGuestlistQuery   ="select u.username from users u,"
			                         + "bookingdetails b,roomdetails r "
			                         + "where u.user_id=b.user_id and"
			                         + " r.room_id=b.room_id and r.hotel_id=? ";  
	String adminViewBookingDateQuery ="select * from bookingdetails where booked_from=?";//subjected to change
	String adminSelectRoomIdQuery    ="select room_id FROM roomdetails where hotel_id=?";
	String adminupdateAvailQuery     ="select r.per_night_rate,r.availability from roomdetails r ,"
			                         + " bookingdetails b where r.room_id=b.room_id and "
			                         + "?>b.booked_from and ?<b.booked_to and room_type=?";
	String adminUpdCustAvailQuery    ="update roomdetails r set availability='no' from bookingdetails b where r.roomid=b.roomid and r.roomid=?";
	String adminUpdNewCustAvailQuery ="update roomdetails r set availability='yes' from bookingdetails b where r.roomid=b.roomid and b.book_to <= ?";
	String adminCheckAvailroomQuery  ="select availability,per_night_rate from roomdetails where room_type=? and hotel_id=?";
}
