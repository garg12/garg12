package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class LoginDAO {

public Connection con = null;
	
	public Connection getConnection(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "hr";
			String pass = "hr";
			con = DriverManager.getConnection(url,user,pass);
		}catch(Exception e){
			System.out.println("Database not connected");
		}
		return con;
	}
	
	public String login(String inputUserName, String inputPassword){
		con = getConnection();
		
		String role = null;
		
		String sql = "select password,role from Users where username=?";
		try{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,inputUserName);
			ResultSet rs1 = ps.executeQuery();
			
			
			
			while(rs1.next()){
				String pass = rs1.getString(1);
				if(pass.equals(inputPassword))
					role = rs1.getString(2);

			}
			
		}catch(Exception e){
			System.out.println("Check your query");
		}
		
		
		return role;
	}
}
