package com.cg.ars.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ars.dao.LoginDAO;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		// TODO Auto-generated method stub
		String inputUserName = request.getParameter("inputUserName");
		String inputPassword = request.getParameter("inputPassword");
		
		LoginDAO newLogin = new LoginDAO();
		String role = null;
		
		role = newLogin.login(inputUserName, inputPassword);
		
//		System.out.println(status);
		
		if(role!=null){
			HttpSession hs = request.getSession();
	        hs.setAttribute("uname", inputUserName);
	        hs.setAttribute("role", role);
	        if(role.matches("Admin")){
	        	RequestDispatcher rd = request.getRequestDispatcher("adminhome.jsp");
		        rd.forward(request, response);
	        }else if(role.matches("Exec")){
	        	RequestDispatcher rd = request.getRequestDispatcher("exechome.jsp");
		        rd.forward(request, response);
	        }
	        
		}else{
			out.println("Who the banana are you?");	
		}
		
		
	}

}
