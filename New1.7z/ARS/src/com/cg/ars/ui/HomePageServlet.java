package com.cg.ars.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HomePageServlet
 */
@WebServlet("/HomePageServlet")
public class HomePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomePageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String source=request.getParameter("source");
		String destination=request.getParameter("destination");
		
		
		String bookingDate=request.getParameter("sourcedate");
		LocalDateTime now = LocalDateTime.now();
		String bookingTime = Integer.toString(now.getHour()) 
					  + ":" +	Integer.toString(now.getMinute()) 
					  + ":" +   Integer.toString(now.getSecond());

		Date bookingDateTime = null;
		Date currentDateTime = new Date();
		
		try {
			bookingDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(bookingDate+" "+bookingTime);
			boolean st = bookingDateTime.after(currentDateTime);
			if(st==true){
				RequestDispatcher rd=request.getRequestDispatcher("flightsearchresults.jsp");
    			rd.forward(request,response);
			}else{
				out.println("Please enter a later date");
				RequestDispatcher rd = request.getRequestDispatcher("homepage.jsp");
				rd.include(request, response);
			}
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
	 }
		
	protected void doPost1(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String source=request.getParameter("source");
		String destination=request.getParameter("destination");
		String datestr=request.getParameter("sourcedate");
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date currDate=new Date();
		try {
	        //if(source != null && destination != null)
	        	Date chosenDate = df.parse(datestr);
	        	
	        	int dec=chosenDate.compareTo(currDate);	      		
	      		if(dec<=0){
	      			if(df.format(currDate).equals(df.format(chosenDate))){
	      			chosenDate=currDate;
	      			}
	      			else{
	      				out.println("Invalid Date, Please Enter a valid Date");
		    			RequestDispatcher rd=request.getRequestDispatcher("homepage.jsp");
		    			rd.include(request,response);
	      			}
	      		}
	      		else{
	      			RequestDispatcher rd=request.getRequestDispatcher("bookflight.jsp");
	    			rd.forward(request,response);
	      		}

	     }catch (Throwable theException) {
	            System.out.println(theException);
	     }
		
		
	 }
}


	
    
	
		

