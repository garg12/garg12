package com.cg.ars.bean;

public class Ticket {

}
